  //     RADIO BRIDGE PACKET DECODER v1.4
// (c)2025 Radio Bridge USA by John Sheldon and Timothy Throop
////////////////////////////////////////////
// NOTE: This decoder is not officially supported and is provided "as-is" as a developer template.
// Multitech / Radio Bridge make no guarantees about use of this decoder in a production environment.
////////////////////////////////////////////


//   RBS301 Series


// If using the sensor listed below, sensor definition files for those sensors must be included with the distribution of this file 
// and must reside in the same directory as the radio_bridge_decoder.js file.


// General defines used in decode

//  Common Events
var RESET_EVENT               = "00";
var SUPERVISORY_EVENT         = "01";
var TAMPER_EVENT              = "02";
var LINK_QUALITY_EVENT        = "FB";
var DOWNLINK_ACK_EVENT        = "FF";

//  Device-Specific Events
var RBS301_PULSE_CNTR_EVENT     = "04";


var decoded = {};

// function called by MultiTech
function decodeUplink(input) {
        return {
                data: Generic_Decoder(input.bytes, input.fPort),
        warnings: [],
        errors: []
    };
}

// The generic decode function called by the above network server specific callbacks
function Generic_Decoder(bytes , port) {
    // data structure which contains decoded messages
    var decode = { data: { Event: "UNDEFINED" }};

    // The first byte contains the protocol version (upper nibble) and packet counter (lower nibble)
    var ProtocolVersion = (bytes[0] >> 4) & 0x0f;
    var PacketCounter = bytes[0] & 0x0f;

    // the event type is defined in the second byte
    var PayloadType = Hex(bytes[1]);

    // the rest of the message decode is dependent on the type of event
    switch (PayloadType) {

        // ==================    RESET EVENT    ====================
        case RESET_EVENT:
            // the hardware version has the major version in the upper nibble, and the minor version in the lower nibble
            var HardwareVersionStr = ((bytes[3] >> 4) & 0x0f) + "." + (bytes[3] & 0x0f);

            // the firmware version has two different formats depending on the most significant bit
            var FirmwareFormat = (bytes[4] >> 7) & 0x01;
            // FirmwareFormat of 0 is old format, 1 is new format
            // old format is has two sections x.y
            // new format has three sections x.y.z
            var FirmwareVersionStr = ""
            if (FirmwareFormat === 0)
                FirmwareVersionStr = bytes[4] + "." + bytes[5];
            else
                FirmwareVersionStr = ((bytes[4] >> 2) & 0x1F) + "." + ((bytes[4] & 0x03) + ((bytes[5] >> 5) & 0x07)) + "." + (bytes[5] & 0x1F);

            FirmwareVersion = (bytes[4]  * 256) + bytes[5]

            decode = {
                protocolVersion: ProtocolVersion,
                packetCounter: PacketCounter,
                deviceType: bytes[2],
                firmwareVersion: FirmwareVersionStr,
                hardwareVersion: HardwareVersionStr
            };
            break;
        // ================   SUPERVISORY EVENT   ==================
        case SUPERVISORY_EVENT:
            // note that the sensor state in the supervisory message is being depreciated, so those are not decoded here
            // battery voltage is in the format x.y volts where x is upper nibble and y is lower nibble
            var BatteryLevel = ((bytes[4] >> 4) & 0x0f) + "." + (bytes[4] & 0x0f);
            BatteryLevel = parseFloat(BatteryLevel);
            // the accumulation count is a 16-bit value
            var AccumulationCount = (bytes[9] * 256) + bytes[10];
            // decode bits for error code byte
            var TamperSinceLastReset = (bytes[2] >> 4) & 0x01;
            var CurrentTamperState = (bytes[2] >> 3) & 0x01;
            var ErrorWithLastDownlink = (bytes[2] >> 2) & 0x01;
            var BatteryLow = (bytes[2] >> 1) & 0x01;
            var RadioCommError = bytes[2] & 0x01;

            decode = {
                protocolVersion: ProtocolVersion,
                packetCounter: PacketCounter,
                accumulationCount: AccumulationCount,
                tamperSinceLastReset: TamperSinceLastReset,
                tamperState: CurrentTamperState,
                errorWithLastDownlink: ErrorWithLastDownlink,
                batteryLow: BatteryLow,
                radioCommError: RadioCommError,
                batteryLevel: BatteryLevel
            };
            break;

        // ==================   TAMPER EVENT    ====================
        case TAMPER_EVENT:
            var TamperEventType = bytes[2];

            // tamper state is 0 for open, 1 for closed
            decode = {
                protocolVersion: ProtocolVersion,
                packetCounter: PacketCounter,
                tamperState : TamperEventType
            };
            break;

        // ==================   LINK QUALITY EVENT    ====================
        case LINK_QUALITY_EVENT:
            var CurrentSubBand = bytes[2];
            var RSSILastDownlink = (-256 + bytes[3]); // RSSI is always negative
            var SNRLastDownlink = bytes[4];

            decode = {
                protocolVersion: ProtocolVersion,
                packetCounter: PacketCounter,
                lastDownlinkRSSI: RSSILastDownlink,
                lastDownlinkSNR: SNRLastDownlink,
                currentSubBand: CurrentSubBand
            };
            break;


        // ================== RBS301 PULSE COUNTER EVENT ====================
        case RBS301_PULSE_CNTR_EVENT:

            //First byte after Uplink Type encodes the Event Type and the fractional component of the pulse rate
            var PulseEventType = (bytes[2] & 0xE0) >> 5; //need to extract upper 3 bits and then bit shift right to 
            
            var PulseRate_Fractional_Component = (bytes[2] & 0x1F) /32; //need to extract lower 5 bits and divide by 2^5 for fractional component of pulse rate
            var PulseRate_Integer_Component = bytes[3];

            var PulseRate = PulseRate_Integer_Component + PulseRate_Fractional_Component;
            
            //Pulse Count is a 5-byte big-endian value extracted from bytes 4-8
            var PulseCount_MSB = bytes[4]; 
            var PulseCount_2nd_MSB = bytes[5];
            var PulseCount_3rd_MSB = bytes[6];
            var PulseCount_4th_MSB = bytes[7];
            var PulseCount_LSB = bytes[8];
            
            
            var PulseCount = 
                  (PulseCount_MSB      * 4294967296) // 2^32
                + (PulseCount_2nd_MSB  * 16777216)   // 2^24
                + (PulseCount_3rd_MSB  * 65536)      // 2^16
                + (PulseCount_4th_MSB  * 256)        // 2^8
                +  PulseCount_LSB;       
           

            decode = {
                protocolVersion: ProtocolVersion,
                packetCounter: PacketCounter,
                pulseCounterEvent: PulseEventType,
                pulseRate: PulseRate,
                pulseCount: PulseCount  //I have the type in the RB301-PULSE-CNTR.json file as uint64 even though this is actually a 5-byte BigInt in JavaScript
            };
            break;
        

        // ==================   DOWNLINK EVENT  ====================
        case DOWNLINK_ACK_EVENT:
            var AckEventType = bytes[2];
            decode = {
                protocolVersion: ProtocolVersion,
                packetCounter: PacketCounter,
                downlinkMessageAck: AckEventType,
            };
            break;

        // end of EventType Case
    }

// return decoded object
  return decode;
}

function Hex(decimal_param) {
    var decimal = ('0' + decimal_param.toString(16).toUpperCase()).slice(-2);
    return decimal;
}


