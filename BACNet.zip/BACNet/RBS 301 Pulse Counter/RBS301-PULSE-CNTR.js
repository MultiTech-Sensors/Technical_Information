  //     RADIO BRIDGE PACKET DECODER v1.5
// (c)2025 Radio Bridge USA by John Sheldon and Timothy Throop
////////////////////////////////////////////
// NOTE: This decoder is not officially supported and is provided "as-is" as a developer template.
// Multitech / Radio Bridge make no guarantees about use of this decoder in a production environment.
////////////////////////////////////////////


//   RBS301 Series


// If using the sensor listed below, sensor definition files for those sensors must be included with the distribution of this file 
// and must reside in the same directory as the radio_bridge_decoder.js file.


// General defines used in decode

//  Common Events
var RESET_EVENT               = "00";
var SUPERVISORY_EVENT         = "01";
var TAMPER_EVENT              = "02";
var LINK_QUALITY_EVENT        = "FB";
var DOWNLINK_ACK_EVENT        = "FF";

//  Device-Specific Events
var RBS301_PULSE_CNTR_EVENT     = "04";


var decoded = {};

// function called by MultiTech
function decodeUplink(input) {
        return {
                data: Generic_Decoder(input.bytes, input.fPort),
        warnings: [],
        errors: []
    };
}

// The generic decode function called by the above network server specific callbacks
function Generic_Decoder(bytes , port) {
    // data structure which contains decoded messages
    var decode = { data: { Event: "UNDEFINED" }};

    // The first byte contains the protocol version (upper nibble) and packet counter (lower nibble)
    var ProtocolVersion = (bytes[0] >> 4) & 0x0f;
    var PacketCounter = bytes[0] & 0x0f;

    // the event type is defined in the second byte
    var PayloadType = Hex(bytes[1]);

    // the rest of the message decode is dependent on the type of event
    switch (PayloadType) {

        // ==================    RESET EVENT    ====================
        case RESET_EVENT:
            // the hardware version has the major version in the upper nibble, and the minor version in the lower nibble
            var HardwareVersionStr = ((bytes[3] >> 4) & 0x0f) + "." + (bytes[3] & 0x0f);

            // the firmware version has two different formats depending on the most significant bit
            var FirmwareFormat = (bytes[4] >> 7) & 0x01;
            // FirmwareFormat of 0 is old format, 1 is new format
            // old format is has two sections x.y
            // new format has three sections x.y.z
            var FirmwareVersionStr = ""
            if (FirmwareFormat === 0)
                FirmwareVersionStr = bytes[4] + "." + bytes[5];
            else
                FirmwareVersionStr = ((bytes[4] >> 2) & 0x1F) + "." + ((bytes[4] & 0x03) + ((bytes[5] >> 5) & 0x07)) + "." + (bytes[5] & 0x1F);

            FirmwareVersion = (bytes[4]  * 256) + bytes[5]

            decode = {
                protocolVersion: ProtocolVersion,
                packetCounter: PacketCounter,
                deviceType: bytes[2],
                firmwareVersion: FirmwareVersionStr,
                hardwareVersion: HardwareVersionStr
            };
            break;
        // ================   SUPERVISORY EVENT   ==================
        case SUPERVISORY_EVENT:
            // note that the sensor state in the supervisory message is being depreciated, so those are not decoded here
            // battery voltage is in the format x.y volts where x is upper nibble and y is lower nibble
            var BatteryLevel = ((bytes[4] >> 4) & 0x0f) + "." + (bytes[4] & 0x0f);
            BatteryLevel = parseFloat(BatteryLevel);
            // the accumulation count is a 16-bit value
            var AccumulationCount = (bytes[9] * 256) + bytes[10];
            // decode bits for error code byte
            var TamperSinceLastReset = (bytes[2] >> 4) & 0x01;
            var CurrentTamperState = (bytes[2] >> 3) & 0x01;
            var ErrorWithLastDownlink = (bytes[2] >> 2) & 0x01;
            var BatteryLow = (bytes[2] >> 1) & 0x01;
            var RadioCommError = bytes[2] & 0x01;

            decode = {
                protocolVersion: ProtocolVersion,
                packetCounter: PacketCounter,
                accumulationCount: AccumulationCount,
                tamperSinceLastReset: TamperSinceLastReset,
                tamperState: CurrentTamperState,
                errorWithLastDownlink: ErrorWithLastDownlink,
                batteryLow: BatteryLow,
                radioCommError: RadioCommError,
                batteryLevel: BatteryLevel
            };
            break;

        // ==================   TAMPER EVENT    ====================
        case TAMPER_EVENT:
            var TamperEventType = bytes[2];

            // tamper state is 0 for open, 1 for closed
            decode = {
                protocolVersion: ProtocolVersion,
                packetCounter: PacketCounter,
                tamperState : TamperEventType
            };
            break;

        // ==================   LINK QUALITY EVENT    ====================
        case LINK_QUALITY_EVENT:
            var CurrentSubBand = bytes[2];
            var RSSILastDownlink = (-256 + bytes[3]); // RSSI is always negative
            var SNRLastDownlink = bytes[4];

            decode = {
                protocolVersion: ProtocolVersion,
                packetCounter: PacketCounter,
                lastDownlinkRSSI: RSSILastDownlink,
                lastDownlinkSNR: SNRLastDownlink,
                currentSubBand: CurrentSubBand
            };
            break;


        // ================== RBS301 PULSE COUNTER EVENT ====================
        case RBS301_PULSE_CNTR_EVENT:

            // First byte after Uplink Type encodes the Event Type and the fractional component of the pulse rate
            // Format: UQ13.3 (13-bit integer, 3-bit fractional) - supports 0-8191.875 PPM
            var PulseEventType = (bytes[2] & 0xE0) >> 5; // Extract upper 3 bits for event type

            var PulseRate_Fractional_Component = (bytes[2] & 0x07) / 8; // Extract lower 3 bits and divide by 2^3 for fractional component

            // Integer Rate is 13 bits: lower 8 bits from byte[3], upper 5 bits from bits 7-3 of byte[4]
            var PulseRate_Integer_Lower = bytes[3];  // bits [7:0] - all 8 bits
            var PulseRate_Integer_Upper = (bytes[4] >> 3) & 0x1F;  // bits [12:8] - extract 5 bits from positions [7:3]
            var PulseRate_Integer_Component = (PulseRate_Integer_Upper << 8) | PulseRate_Integer_Lower;

            var PulseRate = PulseRate_Integer_Component + PulseRate_Fractional_Component;

            // Pulse Count is 35 bits: MS 3 bits from bits 2-0 of byte[4], lower 32 bits from bytes 5-8
            var PulseCount_MS3B = (bytes[4] & 0x07);  // bits 2-0
            var PulseCount_LS32B_Byte1 = bytes[5];
            var PulseCount_LS32B_Byte2 = bytes[6];
            var PulseCount_LS32B_Byte3 = bytes[7];
            var PulseCount_LS32B_Byte4 = bytes[8];

            var PulseCount =
                  (PulseCount_MS3B          * 4294967296) // 2^32
                + (PulseCount_LS32B_Byte1 * 16777216)   // 2^24
                + (PulseCount_LS32B_Byte2 * 65536)      // 2^16
                + (PulseCount_LS32B_Byte3 * 256)        // 2^8
                +  PulseCount_LS32B_Byte4;       
           

            decode = {
                protocolVersion: ProtocolVersion,
                packetCounter: PacketCounter,
                pulseCounterEvent: PulseEventType,
                pulseRate: PulseRate,
                pulseCount: PulseCount  //I have the type in the RB301-PULSE-CNTR.json file as uint64 even though this is actually a 5-byte BigInt in JavaScript
            };
            break;

        // ==================   DOWNLINK EVENT  ====================
        case DOWNLINK_ACK_EVENT:
            // Firmware may send two uplinks per downlink when extended ACKs are enabled:
            // legacy 3-byte (10 FF status) and extended 11-byte (10 FF status + 8-byte echo).
            var StatusCode = bytes[2];
            var DownlinkAckEvent;
            var DownlinkAckFormat;

            if (bytes.length < 11) {
                DownlinkAckFormat = "Legacy";
                switch (StatusCode) {
                    case 0x01: DownlinkAckEvent = "Message Invalid"; break;
                    case 0x02: DownlinkAckEvent = "Message Valid"; break;
                    default: DownlinkAckEvent = "Unknown Legacy Status"; break;
                }
                decode = {
                    protocolVersion: ProtocolVersion,
                    packetCounter: PacketCounter,
                    downlinkMessageAck: StatusCode,
                    downlinkAckEvent: DownlinkAckEvent,
                    downlinkAckFormat: DownlinkAckFormat
                };
            } else {
                DownlinkAckFormat = "Extended";
                switch (StatusCode) {
                    case 0x03: DownlinkAckEvent = "Message Valid"; break;
                    case 0x04: DownlinkAckEvent = "Unsupported Downlink Command"; break;
                    case 0x05: DownlinkAckEvent = "Reserved Bits/Bytes Not Zero"; break;
                    case 0x06: DownlinkAckEvent = "Value Out of Bounds"; break;
                    case 0x07: DownlinkAckEvent = "Unsupported Downlink Option"; break;
                    case 0x08: DownlinkAckEvent = "Zone Confirmed Uplinks Not Supported"; break;
                    case 0x09: DownlinkAckEvent = "No More Than 8 Confirmed Retries"; break;
                    case 0x0A: DownlinkAckEvent = "No More Than 1 Unconfirmed Retry"; break;
                    case 0x0B: DownlinkAckEvent = "LoRa Port Number Above 223"; break;
                    case 0x0C: DownlinkAckEvent = "Device Does Not Support This Sensor"; break;
                    case 0x0D: DownlinkAckEvent = "Misc Configuration Error"; break;
                    case 0x0E: DownlinkAckEvent = "Link Quality Period Less Than 1 Minute"; break;
                    case 0x0F: DownlinkAckEvent = "Improper Message Size"; break;
                    default: DownlinkAckEvent = "Unknown Extended Status"; break;
                }
                var EchoedDownlink = [];
                for (var echoIdx = 3; echoIdx < 11; echoIdx++)
                    EchoedDownlink.push(bytes[echoIdx]);
                decode = {
                    protocolVersion: ProtocolVersion,
                    packetCounter: PacketCounter,
                    downlinkMessageAck: StatusCode,
                    downlinkAckEvent: DownlinkAckEvent,
                    downlinkAckFormat: DownlinkAckFormat,
                    echoedDownlink: EchoedDownlink
                };
            }
            break;


        // end of EventType Case
    }

// return decoded object
  return decode;
}

function Hex(decimal_param) {
    var decimal = ('0' + decimal_param.toString(16).toUpperCase()).slice(-2);
    return decimal;
}


