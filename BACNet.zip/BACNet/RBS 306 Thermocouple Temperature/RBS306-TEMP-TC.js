  //     RADIO BRIDGE PACKET DECODER v1.5
// (c)2025 Radio Bridge USA by John Sheldon and Timothy Throop
////////////////////////////////////////////
// NOTE: This decoder is not officially supported and is provided "as-is" as a developer template.
// Multitech / Radio Bridge make no guarantees about use of this decoder in a production environment.
// v1.5: Extended Downlink ACK/NACK (legacy 3-byte vs extended 11-byte)
////////////////////////////////////////////

// SUPPORTED SENSORS:

//   RBS306 Series (except RBS306-VSHB & RBS306-CMPS)


// General defines used in decode

//  Common Events
var RESET_EVENT               = "00";
var SUPERVISORY_EVENT         = "01";
var TAMPER_EVENT              = "02";
var LINK_QUALITY_EVENT        = "FB";
var DOWNLINK_ACK_EVENT        = "FF";

//  Device-Specific Events
var THERMOCOUPLE_EVENT        = "13";

var decoded = {};

// function called by MultiTech
function decodeUplink(input) {
        return {
                data: Generic_Decoder(input.bytes, input.fPort),
        warnings: [],
        errors: []
    };
}

// The generic decode function called by the above network server specific callbacks
function Generic_Decoder(bytes , port) {
    // data structure which contains decoded messages
    var decode = { data: { Event: "UNDEFINED" }};

    // The first byte contains the protocol version (upper nibble) and packet counter (lower nibble)
    var ProtocolVersion = (bytes[0] >> 4) & 0x0f;
    var PacketCounter = bytes[0] & 0x0f;

    // the event type is defined in the second byte
    var PayloadType = Hex(bytes[1]);

    // the rest of the message decode is dependent on the type of event
    switch (PayloadType) {

        // ==================    RESET EVENT    ====================
        case RESET_EVENT:
            // the hardware version has the major version in the upper nibble, and the minor version in the lower nibble
            var HardwareVersionStr = ((bytes[3] >> 4) & 0x0f) + "." + (bytes[3] & 0x0f);

            // the firmware version has two different formats depending on the most significant bit
            var FirmwareFormat = (bytes[4] >> 7) & 0x01;
            // FirmwareFormat of 0 is old format, 1 is new format
            // old format is has two sections x.y
            // new format has three sections x.y.z
            var FirmwareVersionStr = ""
            if (FirmwareFormat === 0)
                FirmwareVersionStr = bytes[4] + "." + bytes[5];
            else
                FirmwareVersionStr = ((bytes[4] >> 2) & 0x1F) + "." + ((bytes[4] & 0x03) + ((bytes[5] >> 5) & 0x07)) + "." + (bytes[5] & 0x1F);

            FirmwareVersion = (bytes[4]  * 256) + bytes[5]

            decode = {
                protocolVersion: ProtocolVersion,
                packetCounter: PacketCounter,
                deviceType: bytes[2],
                firmwareVersion: FirmwareVersionStr,
                hardwareVersion: HardwareVersionStr
            };
            break;
        // ================   SUPERVISORY EVENT   ==================
        case SUPERVISORY_EVENT:
            // note that the sensor state in the supervisory message is being depreciated, so those are not decoded here
            // battery voltage is in the format x.y volts where x is upper nibble and y is lower nibble
            var BatteryLevel = ((bytes[4] >> 4) & 0x0f) + "." + (bytes[4] & 0x0f);
            BatteryLevel = parseFloat(BatteryLevel);
            // the accumulation count is a 16-bit value
            var AccumulationCount = (bytes[9] * 256) + bytes[10];
            // decode bits for error code byte
            var TamperSinceLastReset = (bytes[2] >> 4) & 0x01;
            var CurrentTamperState = (bytes[2] >> 3) & 0x01;
            var ErrorWithLastDownlink = (bytes[2] >> 2) & 0x01;
            var BatteryLow = (bytes[2] >> 1) & 0x01;
            var RadioCommError = bytes[2] & 0x01;

            decode = {
                protocolVersion: ProtocolVersion,
                packetCounter: PacketCounter,
                accumulationCount: AccumulationCount,
                tamperSinceLastReset: TamperSinceLastReset,
                tamperState: CurrentTamperState,
                errorWithLastDownlink: ErrorWithLastDownlink,
                batteryLow: BatteryLow,
                radioCommError: RadioCommError,
                batteryLevel: BatteryLevel
            };
            break;

        // ==================   TAMPER EVENT    ====================
        case TAMPER_EVENT:
            var EventType = bytes[2];

            // tamper state is 0 for open, 1 for closed
            decode = {
                protocolVersion: ProtocolVersion,
                packetCounter: PacketCounter,
                tamperState : EventType
            };
            break;

        // ==================   LINK QUALITY EVENT    ====================
        case LINK_QUALITY_EVENT:
            var CurrentSubBand = bytes[2];
            var RSSILastDownlink = (-256 + bytes[3]); // RSSI is always negative
            var SNRLastDownlink = bytes[4];

            decode = {
                protocolVersion: ProtocolVersion,
                packetCounter: PacketCounter,
                lastDownlinkRSSI: RSSILastDownlink,
                lastDownlinkSNR: SNRLastDownlink,
                currentSubBand: CurrentSubBand
            };
            break;

        // =================  THERMOCOUPLE EVENT  ==================
        case THERMOCOUPLE_EVENT:
            var EventType = bytes[2];
            // decode is across 16-bits
            var negativeNumber = 0xFFFF0000;
            var Temp16bits = ((bytes[3] << 8) | bytes[4]);

            if(Temp16bits & 0x8000)
            {
                Temperature = (negativeNumber | Temp16bits)/16;
            }
            else
            {
                Temperature = Temp16bits/16;
            }
            var Faults = bytes[5];
            // decode each bit in the fault byte
            var FaultColdOutsideRange = (Faults >> 7) & 0x01;
            var FaultHotOutsideRange = (Faults >> 6) & 0x01;
            var FaultColdAboveThresh = (Faults >> 5) & 0x01;
            var FaultColdBelowThresh = (Faults >> 4) & 0x01;
            var FaultTCTooHigh = (Faults >> 3) & 0x01;
            var FaultTCTooLow = (Faults >> 2) & 0x01;
            var FaultVoltageOutsideRange = (Faults >> 1) & 0x01;
            var FaultOpenCircuit = Faults & 0x01;
            // Decode faults
            if (FaultColdOutsideRange)    FaultCOR = true; else FaultCOR = false;
            if (FaultHotOutsideRange)     FaultHOR = true; else FaultHOR = false;
            if (FaultColdAboveThresh)     FaultCAT = true; else FaultCAT = false;
            if (FaultColdBelowThresh)     FaultCBT = true; else FaultCBT = false;
            if (FaultTCTooHigh)           FaultTCH = true; else FaultTCH = false;
            if (FaultTCTooLow)            FaultTCL = true; else FaultTCL = false;
            if (FaultVoltageOutsideRange) FaultVOR = true; else FaultVOR = false;
            if (FaultOpenCircuit)         FaultOPC = true; else FaultOPC = false;

            decode = {
                protocolVersion: ProtocolVersion,
                packetCounter: PacketCounter,
                thermocoupleEvent: EventType,
                thermocoupleTemperature: Temperature,
                faultColdOutsideRange: FaultCOR,
                faultHotOutsideRange: FaultHOR,
                faultColdAboveThresh: FaultCAT,
                faultColdBelowThresh: FaultCBT,
                faultTCTooHigh: FaultTCH,
                faultTCTooLow: FaultTCL,
                faultVoltageOutsideRange: FaultVOR,
                faultOpenCircuit: FaultOPC
            };
            break;

        // ==================   DOWNLINK EVENT  ====================
        case DOWNLINK_ACK_EVENT:
            // Firmware may send two uplinks per downlink when extended ACKs are enabled:
            // legacy 3-byte (10 FF status) and extended 11-byte (10 FF status + 8-byte echo).
            var StatusCode = bytes[2];
            var DownlinkAckEvent;
            var DownlinkAckFormat;

            if (bytes.length < 11) {
                DownlinkAckFormat = "Legacy";
                switch (StatusCode) {
                    case 0x01: DownlinkAckEvent = "Message Invalid"; break;
                    case 0x02: DownlinkAckEvent = "Message Valid"; break;
                    default: DownlinkAckEvent = "Unknown Legacy Status"; break;
                }
                decode = {
                    protocolVersion: ProtocolVersion,
                    packetCounter: PacketCounter,
                    downlinkMessageAck: StatusCode,
                    downlinkAckEvent: DownlinkAckEvent,
                    downlinkAckFormat: DownlinkAckFormat
                };
            } else {
                DownlinkAckFormat = "Extended";
                switch (StatusCode) {
                    case 0x03: DownlinkAckEvent = "Message Valid"; break;
                    case 0x04: DownlinkAckEvent = "Unsupported Downlink Command"; break;
                    case 0x05: DownlinkAckEvent = "Reserved Bits/Bytes Not Zero"; break;
                    case 0x06: DownlinkAckEvent = "Value Out of Bounds"; break;
                    case 0x07: DownlinkAckEvent = "Unsupported Downlink Option"; break;
                    case 0x08: DownlinkAckEvent = "Zone Confirmed Uplinks Not Supported"; break;
                    case 0x09: DownlinkAckEvent = "No More Than 8 Confirmed Retries"; break;
                    case 0x0A: DownlinkAckEvent = "No More Than 1 Unconfirmed Retry"; break;
                    case 0x0B: DownlinkAckEvent = "LoRa Port Number Above 223"; break;
                    case 0x0C: DownlinkAckEvent = "Device Does Not Support This Sensor"; break;
                    case 0x0D: DownlinkAckEvent = "Misc Configuration Error"; break;
                    case 0x0E: DownlinkAckEvent = "Link Quality Period Less Than 1 Minute"; break;
                    case 0x0F: DownlinkAckEvent = "Improper Message Size"; break;
                    default: DownlinkAckEvent = "Unknown Extended Status"; break;
                }
                var EchoedDownlink = [];
                for (var echoIdx = 3; echoIdx < 11; echoIdx++)
                    EchoedDownlink.push(bytes[echoIdx]);
                decode = {
                    protocolVersion: ProtocolVersion,
                    packetCounter: PacketCounter,
                    downlinkMessageAck: StatusCode,
                    downlinkAckEvent: DownlinkAckEvent,
                    downlinkAckFormat: DownlinkAckFormat,
                    echoedDownlink: EchoedDownlink
                };
            }
            break;


        // end of EventType Case
    }

// return decoded object
  return decode;
}

function Hex(decimal) {
    var decimal = ('0' + decimal.toString(16).toUpperCase()).slice(-2);
    return decimal;
}


